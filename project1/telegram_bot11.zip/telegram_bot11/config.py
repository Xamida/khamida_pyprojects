CATEGORIES = {
    'Smart TV': 'products/category/televizory-i-smart-televizory-8/smart-tv-217',
    'Smartphones': 'products/category/telefonlar-17/smartfonlar-40',
    'Watches': 'products/category/gadjetlar-18/aqlli-soatlar-uchun-aksessuarlar-1337',
    'Quloqchinlar': 'products/category/quloqchin-va-garnituralar-1278/quloqchinlar-26'
}

def get_value(category):
    for key, value in CATEGORIES.items():
        if key == category:
            return value

















